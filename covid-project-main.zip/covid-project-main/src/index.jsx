import React from "React";
import ReactDOM from "React DOM";


ReactDOM.render(
    <>
    <h1>hello</h1>
    </>
    ,getElemenyByID('root')
)